# coding=utf-8
"""
DNSPOD API
DNSPOD 接口解析操作库
http://www.dnspod.com/docs/domains.html
@author: New Future
"""

from dns.dnspod import *

API.SITE = "api.dnspod.com"
API.DEFAULT = "default"
API.TOKEN_PARAM = "user_token"
